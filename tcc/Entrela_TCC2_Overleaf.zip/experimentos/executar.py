"""Experimentos do manuscrito TCC 2. Executar com o Entrela 0.12.0 instalado.

python experimentos/executar.py --saida dados
O diretório de saída deve estar vazio: resultados anteriores não são sobrescritos.
"""
from __future__ import annotations

import argparse
import csv
from dataclasses import asdict
from datetime import datetime, timezone
from importlib.metadata import version
import json
from pathlib import Path
import platform
import subprocess
import sys

import numpy as np
from scipy.linalg import expm
from qiskit.quantum_info import DensityMatrix, Statevector, partial_trace
from core.types import SystemConfig, SimulationProtocol, NoiseConfig, ExperimentConfig
from core.simulation import run_experiment
from core.circuits import build_circuit
from core.noise import build_noise_model
from core.mitigation import run_zne
from core.metrics import fidelity, purity


def exact_ising(n, J=1.0, h=0.5, t=1.0):
    """Referência independente da montagem do Hamiltoniano no Entrela."""
    eye = np.eye(2, dtype=complex)
    x = np.array([[0, 1], [1, 0]], dtype=complex)
    z = np.diag([1.0, -1.0])

    def term(operators):
        matrix = np.ones((1, 1), dtype=complex)
        for q in reversed(range(n)):
            matrix = np.kron(matrix, operators.get(q, eye))
        return matrix

    H = sum((J * term({q: z, q + 1: z}) for q in range(n - 1)), np.zeros((2**n, 2**n), complex))
    H += sum((h * term({q: x}) for q in range(n)), np.zeros_like(H))
    initial = np.zeros(2**n, dtype=complex)
    initial[0] = 1
    return Statevector(expm(-1j * t * H) @ initial)


def encode_state(state):
    a = np.asarray(state.data)
    return dict(real=a.real.tolist(), imag=a.imag.tolist())


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--saida', type=Path, default=Path('dados'))
    args = parser.parse_args()
    out = args.saida
    out.mkdir(parents=True, exist_ok=True)
    if any(out.iterdir()):
        parser.error('Use um diretório de saída vazio para preservar as execuções anteriores.')
    started = datetime.now(timezone.utc).isoformat()
    rows = dict(convergencia=[], despolarizador=[], termico=[], zne=[], temporal=[])
    raw = []

    def evaluate(n, steps, noise, order=2, snapshots=False, group=''):
        cfg = ExperimentConfig(SystemConfig(n, 'Ising', 1.0, 0.5, False, 'zero'),
                               SimulationProtocol(1.0, steps, snapshots, order), noise,
                               shots=8192, seed=42)
        exp = run_experiment(cfg)
        r = exp.result
        exact = exact_ising(n)
        row = dict(n=n, passos=steps, ordem=order, p1=noise.p1 if noise.enabled and noise.kind == 'Despolarizador' else 0.,
                   p2=noise.p2 if noise.enabled and noise.kind == 'Despolarizador' else 0.,
                   T1_us=noise.t1_us if noise.enabled and noise.kind == 'Termico' else 0.,
                   T2_us=noise.t2_us if noise.enabled and noise.kind == 'Termico' else 0.,
                   profundidade=r.circuit_depth, F_circuito=r.fidelity,
                   F_exata=fidelity(r.final_state, exact),
                   infidelidade_trotter=max(0., 1-fidelity(r.ideal_final_state, exact)),
                   pureza=r.purity, energia=r.energy, duracao_s=exp.duration_s)
        assert r.final_state.is_valid()
        assert 1/(2**n)-1e-10 <= r.purity <= 1+1e-10
        raw.append(dict(grupo=group, config=asdict(cfg), metricas=row, counts=r.counts,
                        metadata=r.metadata, final=encode_state(r.final_state),
                        ideal=encode_state(r.ideal_final_state), exact=encode_state(exact)))
        if snapshots:
            raw[-1]['tempos'] = r.times
            raw[-1]['snapshots'] = [encode_state(state) for state in r.states]
            raw[-1]['snapshots_ideais'] = [encode_state(state) for state in r.ideal_statevectors]
        print(group, n, steps, order, noise.kind, flush=True)
        return row, exp

    for n in (2, 4):
        for order in (2, 4):
            for steps in (1, 2, 4, 8, 16, 32, 64):
                row, _ = evaluate(n, steps, NoiseConfig(enabled=False), order, group='convergencia')
                rows['convergencia'].append(row)
        for p in (0., .001, .005, .01):
            for steps in (2, 4, 8, 16, 32):
                row, _ = evaluate(n, steps, NoiseConfig(enabled=p > 0, p1=p, p2=5*p), group='despolarizador')
                rows['despolarizador'].append(row)
        for t1 in (25., 50., 100.):
            for steps in (4, 16, 32):
                row, _ = evaluate(n, steps, NoiseConfig(kind='Termico', t1_us=t1, t2_us=.6*t1), group='termico')
                rows['termico'].append(row)

    for n in (2, 4):
        for steps in (4, 16):
            for p in (.001, .01):
                circuit, _ = build_circuit(n, 'Ising', 1., .5, False, 1., steps, False,
                                            measure=False, save_final=False)
                for seed in (101, 102, 103, 104, 105):
                    noise = NoiseConfig(p1=p, p2=5*p)
                    result = run_zne(circuit, build_noise_model(noise), [1, 3, 5],
                                     shots=8192, method='linear', seed=seed, qubit=0)
                    row = dict(n=n, passos=steps, p1=p, p2=5*p, seed=seed,
                               ideal=result['ideal_observable'], bruto=result['measured'][0],
                               extrapolado=result['extrapolated'],
                               erro_bruto=result['baseline_absolute_error'],
                               erro_zne=result['extrapolated_absolute_error'],
                               stderr_zne=result['extrapolated_stderr'],
                               melhora=int(result['extrapolated_absolute_error'] < result['baseline_absolute_error']))
                    rows['zne'].append(row)
                    raw.append(dict(grupo='zne', config=dict(n=n, passos=steps, p1=p, p2=5*p), resultado=result))
                    print('zne', n, steps, p, seed, flush=True)

    _, exp = evaluate(2, 16, NoiseConfig(p1=.005, p2=.025), snapshots=True, group='temporal')
    for i, (time, state, ideal) in enumerate(zip(exp.result.times, exp.result.states, exp.result.ideal_statevectors)):
        reduced = partial_trace(DensityMatrix(state), [1])
        local_ideal = partial_trace(ideal, [1])
        row = dict(snapshot=i, tempo=time, pureza_global=purity(state), pureza_local=purity(reduced),
                   pureza_local_ideal=purity(local_ideal), F_circuito=fidelity(state, ideal),
                   F_exata=fidelity(state, exact_ising(2, t=time)))
        rows['temporal'].append(row)

    for name, table in rows.items():
        with (out/f'{name}.csv').open('w', newline='', encoding='utf-8') as f:
            writer = csv.DictWriter(f, fieldnames=list(table[0]))
            writer.writeheader(); writer.writerows(table)
    (out/'execucoes.json').write_text(json.dumps(raw, indent=2, ensure_ascii=False), encoding='utf-8')
    try:
        import core
        code_dir = Path(core.__file__).resolve().parent.parent
        commit = subprocess.check_output(['git', '-C', str(code_dir), 'rev-parse', 'HEAD'], text=True, stderr=subprocess.DEVNULL).strip()
        dirty = subprocess.check_output(['git', '-C', str(code_dir), 'status', '--porcelain'], text=True, stderr=subprocess.DEVNULL).strip()
    except (OSError, subprocess.CalledProcessError):
        commit, dirty = 'indisponível; registrar versão instalada', 'não verificado'
    manifest = dict(inicio_utc=started, fim_utc=datetime.now(timezone.utc).isoformat(),
                    commit=commit, alteracoes_versionadas=dirty, python=sys.version,
                    plataforma=platform.platform(), maquina=platform.machine(),
                    processador=platform.processor(),
                    versoes={p:version(p) for p in ('entrela','qiskit','qiskit-aer','numpy','scipy','matplotlib','PySide6')},
                    linhas={k:len(v) for k,v in rows.items()},
                    observacao='Execução automatizada em Linux. Não representa hardware quântico nem estudo de usabilidade.')
    (out/'manifesto.json').write_text(json.dumps(manifest,indent=2,ensure_ascii=False),encoding='utf-8')
    print(json.dumps(manifest,indent=2,ensure_ascii=False))


if __name__ == '__main__':
    main()
