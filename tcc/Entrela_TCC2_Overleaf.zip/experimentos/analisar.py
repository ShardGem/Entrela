"""Gera figuras e tabelas a partir dos CSV, sem executar simulações.

Executar na raiz do projeto: python experimentos/analisar.py
"""
import csv
from pathlib import Path
import statistics as st

import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
import numpy as np

ROOT = Path(__file__).resolve().parent.parent
FIG = ROOT/'figuras'
TAB = ROOT/'tabelas'
FIG.mkdir(exist_ok=True); TAB.mkdir(exist_ok=True)
plt.rcParams.update({'font.family':'DejaVu Sans','font.size':10,'axes.spines.top':False,
                     'axes.spines.right':False,'axes.grid':True,'grid.alpha':.2,
                     'savefig.bbox':'tight','pdf.fonttype':42})


def read(name):
    with (ROOT/'dados'/f'{name}.csv').open(encoding='utf-8') as f:
        return [{k:float(v) for k,v in row.items()} for row in csv.DictReader(f)]


def choose(rows, **kw):
    return [r for r in rows if all(r[k] == v for k,v in kw.items())]


def save(fig, name):
    fig.savefig(FIG/f'{name}.pdf')
    fig.savefig(FIG/f'{name}.png', dpi=160)
    plt.close(fig)


def dec(x, digits=6):
    return f'{x:.{digits}f}'.replace('.', ',')


conv=read('convergencia')
fig,axes=plt.subplots(1,2,figsize=(10,3.5),layout='constrained')
for ax,n in zip(axes,(2,4)):
    for order,color in ((2,'#3659a6'),(4,'#a64d37')):
        r=choose(conv,n=n,ordem=order)
        x=[t['passos'] for t in r]; y=np.array([t['infidelidade_trotter'] for t in r])
        ok=y>1e-14
        ax.loglog(np.array(x)[ok],y[ok],'o-',label=f'Ordem {order}',color=color)
    ax.set(title=f'{n} qubits',xlabel='Passos de Trotter N',ylabel='Infidelidade à referência exata')
    ax.legend()
save(fig,'convergencia')

dep=read('despolarizador')
fig,axes=plt.subplots(1,2,figsize=(10,3.5),layout='constrained')
for ax,n in zip(axes,(2,4)):
    for p,color in ((0.,'#262626'),(.001,'#3659a6'),(.005,'#cb8c2b'),(.01,'#a64d37')):
        r=choose(dep,n=n,p1=p)
        ax.plot([t['passos'] for t in r],[t['F_exata'] for t in r],'o-',label=f'p₁={p:g}',color=color)
    ax.set(title=f'{n} qubits',xlabel='Passos de Trotter N',ylabel='Fidelidade à referência exata',ylim=(0,1.03))
    ax.legend(fontsize=8)
save(fig,'despolarizador')

therm=read('termico')
fig,axes=plt.subplots(1,2,figsize=(10,3.5),layout='constrained')
for ax,n in zip(axes,(2,4)):
    for t,color in ((25.,'#a64d37'),(50.,'#cb8c2b'),(100.,'#3659a6')):
        r=choose(therm,n=n,T1_us=t)
        ax.plot([x['passos'] for x in r],[x['F_exata'] for x in r],'o-',label=f'T₁={t:g} μs',color=color)
    ax.set(title=f'{n} qubits; T₂=0,6 T₁',xlabel='Passos de Trotter N',ylabel='Fidelidade à referência exata')
    ax.legend(fontsize=8)
save(fig,'termico')

zne=read('zne')
summary=[]
for n in (2,4):
    for steps in (4,16):
        for p in (.001,.01):
            r=choose(zne,n=n,passos=steps,p1=p)
            summary.append(dict(n=n,N=steps,p=p,bruto=st.mean(x['erro_bruto'] for x in r),
                                zne=st.mean(x['erro_zne'] for x in r),
                                sd_bruto=st.stdev(x['erro_bruto'] for x in r),
                                sd_zne=st.stdev(x['erro_zne'] for x in r),
                                melhora=sum(int(x['melhora']) for x in r)))
fig,ax=plt.subplots(figsize=(10,4),layout='constrained')
x=np.arange(len(summary));w=.36
ax.bar(x-w/2,[r['bruto'] for r in summary],w,yerr=[r['sd_bruto'] for r in summary],capsize=3,label='Sem mitigação',color='#9ba8be')
ax.bar(x+w/2,[r['zne'] for r in summary],w,yerr=[r['sd_zne'] for r in summary],capsize=3,label='ZNE linear',color='#3659a6')
ax.set_xticks(x,[f"n={r['n']}; N={r['N']}\np₁={r['p']:g}" for r in summary],fontsize=8)
ax.set_ylabel('Erro absoluto de ⟨Z₀⟩: média e desvio-padrão entre sementes')
ax.legend();save(fig,'zne')

temp=read('temporal')
fig,ax=plt.subplots(figsize=(8,3.5),layout='constrained')
for key,label,color in (('pureza_global','Pureza global ruidosa','#3659a6'),('pureza_local','Pureza local ruidosa q₀','#a64d37'),('pureza_local_ideal','Pureza local ideal q₀','#cb8c2b')):
    ax.plot([r['tempo'] for r in temp],[r[key] for r in temp],'o-',label=label,color=color,markersize=3)
ax.set(xlabel='Tempo adimensional (ℏ=1)',ylabel='Pureza',ylim=(.25,1.03));ax.legend(fontsize=9)
save(fig,'pureza')

table='\\begin{tabular}{rrrrrrr}\n\\toprule\n$n$ & $N$ & $p_1$ & $\\bar e_{\\mathrm{bruto}}$ & $\\bar e_{\\mathrm{ZNE}}$ & $s(e_{\\mathrm{ZNE}})$ & Melhoras\\\\\n\\midrule\n'
for r in summary:
    table+=f"{r['n']} & {r['N']} & {dec(r['p'],3)} & {dec(r['bruto'],4)} & {dec(r['zne'],4)} & {dec(r['sd_zne'],4)} & {r['melhora']}/5 \\\\\n"
table+='\\bottomrule\n\\end{tabular}\n'
(TAB/'zne.tex').write_text(table,encoding='utf-8')

table='\\begin{tabular}{rrrrr}\n\\toprule\n$n$ & $p_1$ & $N$ selecionado & $F_{\\mathrm{ex}}$ & Pureza global\\\\\n\\midrule\n'
for n in (2,4):
    for p in (0.,.001,.005,.01):
        r=max(choose(dep,n=n,p1=p),key=lambda x:x['F_exata'])
        table+=f"{n} & {dec(p,3)} & {int(r['passos'])} & {dec(r['F_exata'])} & {dec(r['pureza'])} \\\\\n"
table+='\\bottomrule\n\\end{tabular}\n'
(TAB/'melhores.tex').write_text(table,encoding='utf-8')
with (ROOT/'dados'/'zne_resumo.csv').open('w',newline='',encoding='utf-8') as f:
    writer=csv.DictWriter(f,fieldnames=list(summary[0]));writer.writeheader();writer.writerows(summary)
print('Gerados cinco gráficos (PDF/PNG), duas tabelas LaTeX e o resumo CSV da ZNE.')
