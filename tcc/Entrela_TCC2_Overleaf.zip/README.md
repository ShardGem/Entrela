# Entrela — TCC 2, versão de desenvolvimento

Continuidade do trabalho de Árthur Silva Medeiros, orientado pela Profa. Flávia Maria Alves Lopes, no curso de Ciência da Computação da UDF.

Esta versão desenvolve o texto do TCC 1 em seis capítulos: introdução; fundamentação e trabalhos relacionados; metodologia; implementação; resultados e discussão; conclusão. Inclui resultados de uma bateria computacional inicial real, e não projeções numéricas. Não é uma versão aprovada pela banca ou revisada pela orientadora.

## Abrir no Overleaf

1. Crie um novo projeto com **Upload Project** e envie o ZIP.
2. Selecione `TCC.tex` como documento principal e **pdfLaTeX** como compilador. Use uma distribuição TeX Live recente.
3. Compile o projeto. O Overleaf gerencia as passagens do BibTeX e as referências cruzadas.

As figuras e tabelas já estão prontas. Não é necessário instalar Python nem executar os experimentos para compilar o manuscrito. O projeto utiliza abnTeX2, disponível no Overleaf; não precisa do estilo SBC antigo. A identidade institucional e os elementos do projeto de origem foram preservados, com limpeza de pacotes e revisão da hierarquia de seções.

Compilação local com TeX Live completo, incluindo idioma português e abnTeX2:

```sh
latexmk -pdf -interaction=nonstopmode -halt-on-error TCC.tex
```

## O que mudou em relação ao TCC 1

- A pergunta de pesquisa e os objetivos passam a incluir desenvolvimento, verificação e avaliação.
- A fundamentação foi aprofundada em matrizes densidade, estados reduzidos e referências de fidelidade.
- Foram corrigidos T2 ≤ 2T1, a orientação do estado fundamental, o sinal do acoplamento e a interpretação da pureza.
- O canal despolarizador agora segue o parâmetro efetivamente usado no Aer; a convenção alternativa de erros de Pauli é explicitada.
- A ZNE avalia um observável e não afirma reconstruir um estado com fidelidade mitigada.
- O capítulo de implementação descreve o código 0.12.0 efetivamente inspecionado, incluindo editor gráfico e persistência.
- As projeções foram substituídas por dados, gráficos, análise e limitações. Nenhuma melhora foi assumida antecipadamente.
- As imagens antigas de código deram lugar a arquitetura redesenhada e capturas atuais. Material produzido pelo autor é organizado em apêndices, sem anexos artificiais.
- Foram removidos a alegação de revisão sistemática sem protocolo e a afirmação incorreta de ausência de Bloch 3D no QuTiP.
- A epígrafe foi omitida nesta versão para não manter uma tradução e atribuição sem conferência da fonte.

## Reprodução dos experimentos

Os dados originais estão em `dados/`. Preserve-os. A fonte avaliada está em `experimentos/software/entrela-0.12.0.tar.gz`, extraída do commit completo registrado no manifesto. O script também pode ser executado com esse mesmo commit instalado a partir do repositório.

Exemplo em Linux/macOS, na raiz deste projeto:

```sh
python3.12 -m venv .venv
. .venv/bin/activate
python -m pip install -r experimentos/requirements.txt
python -m pip install --no-deps experimentos/software/entrela-0.12.0.tar.gz
python experimentos/executar.py --saida dados_reproducao
```

No Windows/PowerShell:

```powershell
py -3.12 -m venv .venv
.\.venv\Scripts\python.exe -m pip install -r experimentos/requirements.txt
.\.venv\Scripts\python.exe -m pip install --no-deps experimentos/software/entrela-0.12.0.tar.gz
.\.venv\Scripts\python.exe experimentos/executar.py --saida dados_reproducao
```

O script exige uma pasta de saída vazia. Registra 28 condições de convergência, 40 de despolarização, 18 térmicas, 40 chamadas ZNE (três fatores por chamada) e uma evolução com 17 snapshots. São 127 execuções principais e 207 condições de circuito, além das referências internas. As métricas de estado são determinísticas; somente as estimativas por shots usam repetição por sementes. Não são dados de hardware quântico.

Para regenerar a apresentação dos dados originais:

```sh
python experimentos/analisar.py
```

Para apresentar uma reprodução, trabalhe numa cópia do projeto e coloque a pasta de saída reproduzida em `dados/`. Não misture figuras ou tabelas de execuções distintas. As versões fixadas descrevem o ambiente observado; não garantem igualdade bit a bit entre plataformas. O manifesto registra o commit quando os fontes estão em um checkout Git; em instalação por arquivo, use a identificação e os hashes fornecidos no pacote.

Os testes podem ser reproduzidos extraindo a cópia do software, usando as dependências registradas em `experimentos/requirements.txt` e executando `python -m pytest -q` na raiz do software. Em Linux sem janela, defina `QT_QPA_PLATFORM=offscreen`. O registro desta entrega é `dados/testes.log`.

## Dados e proveniência

- `manifesto.json`: versões, plataforma, horários UTC e commit.
- `execucoes.json`: configurações, contagens, estados finais e referências, além dos detalhes de ZNE.
- `convergencia.csv`, `despolarizador.csv`, `termico.csv`, `temporal.csv`: métricas numéricas.
- `zne.csv` e `zne_resumo.csv`: resultados por semente e estatísticas descritivas.
- `ambiente.txt`: dependências observadas.
- `testes.log`: saída da suíte executada.
- `SHA256SUMS.txt`, na raiz: integridade dos arquivos do pacote.

## Pendências para a versão de defesa

- Revisar o manuscrito e o recorte com a orientadora.
- Conferir o manual vigente da UDF: margens, elementos pré-textuais, referências e demais exigências. Esta adaptação não é uma certificação de conformidade institucional.
- Emitir/validar a ficha catalográfica e informar banca e data de aprovação. Os espaços estão identificados no texto.
- Conferir as referências bibliográficas e ampliar a discussão conforme o escopo acordado. Fontes de software são identificadas como documentação/código, não como artigos científicos.
- Documentar uma reprodução externa e a validação manual no equipamento de apresentação.
- Considerar ampliar a grade para N=1, comparar ordens sob ruído e igualar o orçamento da avaliação da ZNE. Os limites atuais são relatados no texto.
- Um estudo com usuários ou hardware quântico exige metodologia própria; nenhum deles foi apresentado como realizado.

As instruções e exemplos de código do projeto LaTeX original foram tratados como conteúdo documental. A entrega não altera o repositório remoto nem a versão anterior enviada pelo autor.
